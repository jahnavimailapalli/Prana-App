package com.example.prana

import android.annotation.SuppressLint
import android.content.Context
import android.net.ConnectivityManager
import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.SearchView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.*
import kotlin.math.pow

class BloodSearchActivity : AppCompatActivity() {
    private lateinit var searchView: SearchView
    private lateinit var userMobileNumber: String
    private lateinit var userBloodGroup: String
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: BloodSearchAdapter
    private lateinit var userlatitude:String
    private lateinit var userlongitude:String
    private lateinit var usermobilenumber:String
    private lateinit var hospitalname:String
    private lateinit var hospitalnumber:String
    private lateinit var patientid:String
    private lateinit var usersDatabaseRef: DatabaseReference
    private var fcmsearch:String=""
    private lateinit var progress:ProgressBar


    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_blood_search)
        checkInternetConnection()

        // Initialize UI components
        searchView = findViewById(R.id.search_view)
        progress=findViewById(R.id.progressBar_bloodsearch)

        // Get user data from intent
        userMobileNumber = intent.getStringExtra("mymobile").toString()
        userBloodGroup = intent.getStringExtra("BLOOD_GROUP").toString()
        usermobilenumber=intent.getStringExtra("mymobile").toString()
        fcmsearch=intent.getStringExtra("fcmmain").toString()
        hospitalname=intent.getStringExtra("hospitalname").toString()
        hospitalnumber=intent.getStringExtra("hospitalmobile").toString()
        patientid=intent.getStringExtra("patientId").toString()

        userlatitude=intent.getStringExtra("lati").toString()
        userlongitude=intent.getStringExtra("longi").toString()
        usersDatabaseRef = FirebaseDatabase.getInstance().getReference("Users")
        // Setup RecyclerView
        recyclerView = findViewById(R.id.recycler)
        recyclerView.layoutManager = LinearLayoutManager(this)
        FetchdatafromRealtimeDatabase()



        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                adapter.filter.filter(newText)
                return false
            }
        })
    }
    private fun FetchdatafromRealtimeDatabase() {
        progress.visibility = View.VISIBLE
        val id = "Users" // Your database ID
        val database = FirebaseDatabase.getInstance()
        val ref = database.getReference(id)

        ref.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val donorsList = mutableListOf<DonorClass>()

                snapshot.children.forEach { dataSnapshot ->
                    val bloodgroup = dataSnapshot.child("bloodgroup").value as String? ?: ""

                    // Filter donors based on blood group
                    if (bloodgroup == userBloodGroup) {
                        val adress = dataSnapshot.child("address").value as String? ?: ""
                        val age = dataSnapshot.child("age").value as String? ?: ""
                        val pincode = dataSnapshot.child("pincode").value as String? ?: ""
                        val state = dataSnapshot.child("state").value as String? ?: ""
                        val phnumber = dataSnapshot.child("mobilenumber").value as String? ?: ""
                        val name = dataSnapshot.child("name").value as String? ?: ""
                        val city = dataSnapshot.child("city").value as String? ?: ""
                        val longt = dataSnapshot.child("longitude").value as String? ?: ""
                        val lat = dataSnapshot.child("latitude").value as String? ?: ""
                        val district = dataSnapshot.child("district").value as String? ?: ""
                        val fcmKey = dataSnapshot.child("key").value as String? ?: ""
                        val myfcm = fcmsearch

                        // Retrieve other fields as needed

                        val distance = calculateDistance(userlatitude, userlongitude, lat, longt)

                        val donor = DonorClass(
                            adress, age, pincode, state, phnumber, name, city, distance,
                            bloodgroup, district, fcmKey, myfcm,hospitalname,patientid,hospitalnumber
                        )
                        donorsList.add(donor)
                    }
                }

                // Sort the donors list by distance
                donorsList.sortBy { it.distance }

                if (donorsList.isNotEmpty()){
                    adapter = BloodSearchAdapter(donorsList)
                    recyclerView.adapter = adapter
                    progress.visibility = View.INVISIBLE

                }


            }

            override fun onCancelled(error: DatabaseError) {
                showToast( "no message ${error.message}")
                // Handle errors here
            }
        })
    }

    private fun showToast(msg:String) {
        //nothing found

    }


    fun calculateDistance(lat1: String, lon1: String, lat2: String, lon2: String): Double {
        val lat1Rad = Math.toRadians(lat1.toDouble())
        val lon1Rad = Math.toRadians(lon1.toDouble())
        val lat2Rad = Math.toRadians(lat2.toDouble())
        val lon2Rad = Math.toRadians(lon2.toDouble())

        val deltaLat = lat2Rad - lat1Rad
        val deltaLon = lon2Rad - lon1Rad

        val a = Math.sin(deltaLat / 2).pow(2) + Math.cos(lat1Rad) * Math.cos(lat2Rad) * Math.sin(
            deltaLon / 2
        ).pow(2)
        val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))

        // Earth's radius in kilometers
        val earthRadius = 6371.0

        return earthRadius * c
    }
    private fun checkInternetConnection() {
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNetworkInfo = connectivityManager.activeNetworkInfo
        val isConnected = activeNetworkInfo != null && activeNetworkInfo.isConnectedOrConnecting
        if (!isConnected) {
            // Show a dialog box indicating no internet connection
            val builder = AlertDialog.Builder(this)
            builder.setTitle("No Internet Connection")
                .setMessage("Please check your internet connection and try again.")
                .setPositiveButton("OK") { dialog, _ ->
                    dialog.dismiss()
                    checkInternetConnection()
                }
                .setCancelable(false)
                .show()
        }
    }
}
