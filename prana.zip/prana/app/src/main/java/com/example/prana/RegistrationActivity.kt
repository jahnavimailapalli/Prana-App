package com.example.prana

import android.annotation.SuppressLint
import android.content.Context
import android.health.connect.datatypes.units.Length
import android.net.ConnectivityManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AlertDialog

class RegistrationActivity : AppCompatActivity() {

    private lateinit var verifyotp:Button
    private lateinit var sendotp:Button

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registration)

        checkInternetConnection()

        verifyotp=findViewById(R.id.verifyotpbutton_signupactivity)
        sendotp=findViewById(R.id.sendotpbutton_signupactivity)
        sendotp.visibility=View.INVISIBLE

        verifyotp.setOnClickListener {
            Toast.makeText(this, "Verified", Toast.LENGTH_SHORT).show()

        }
    }
    private fun checkInternetConnection() {
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNetworkInfo = connectivityManager.activeNetworkInfo
        val isConnected = activeNetworkInfo != null && activeNetworkInfo.isConnectedOrConnecting
        if (!isConnected) {
            // Show a dialog box indicating no internet connection
            val builder = AlertDialog.Builder(this)
            builder.setTitle("No Internet Connection")
                .setMessage("Please check your internet connection and try again.")
                .setPositiveButton("OK") { dialog, _ ->
                    dialog.dismiss()
                    checkInternetConnection()
                }
                .setCancelable(false)
                .show()
        }
    }
}