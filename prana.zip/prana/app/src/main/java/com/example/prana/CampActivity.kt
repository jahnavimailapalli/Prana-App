package com.example.prana

import android.annotation.SuppressLint
import android.app.DatePickerDialog
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.net.ConnectivityManager
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.DatePicker
import android.widget.EditText
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.tasks.Task
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.Response
import org.json.JSONObject
import java.io.IOException
import java.util.Calendar
import java.util.Locale
import kotlin.math.pow

class CampActivity : AppCompatActivity() {

    private lateinit var campName: EditText
    private lateinit var campMobileNumber: EditText
    private lateinit var campCity: EditText
    private lateinit var campDistrict: EditText
    private lateinit var campAddress: EditText
    private lateinit var campPincode: EditText
    private lateinit var saveButton: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var editButton: Button
    private lateinit var date: TextView
    private lateinit var campDate: String
    private lateinit var numberOfDaysLeftForCamp: String
    private lateinit var usersDatabaseRef: DatabaseReference
    private lateinit var mainMobileNum: String
    private lateinit var mainCampCity: String
    private lateinit var longitudeTxt: String
    private lateinit var latitudeTxt: String
    private var mykey:String=""
    private lateinit var progress:ProgressBar
    private lateinit var close:ImageView

    private lateinit var fusedLocationProviderClient: FusedLocationProviderClient

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_camp)


        // Initialize views
        campName = findViewById(R.id.name_camp)
        campMobileNumber = findViewById(R.id.mobilenumber_camp)
        campCity = findViewById(R.id.city_camp)
        campDistrict = findViewById(R.id.district_camp)
        campAddress = findViewById(R.id.adress_camp)
        campPincode = findViewById(R.id.pincode_camp)
        saveButton = findViewById(R.id.saveandnotifubutton_camp)
        progressBar = findViewById(R.id.progressBarcamp)
        editButton = findViewById(R.id.editbutton_camp)
        date = findViewById(R.id.date_camp)
        progress=findViewById(R.id.progressBarcamp)
        close=findViewById(R.id.backarrow_profile)

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this)

        checkInternetConnection()
        getLocation()


        mainMobileNum = intent.getStringExtra("usermobile").toString()
        mykey=intent.getStringExtra("mykey").toString()

        saveButton.setOnClickListener {
            // Check if all necessary fields are filled
            if (areFieldsFilled()) {
                // If data is valid, save to Firebase
                saveDataToFirebase()
            } else {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            }
        }
        close.setOnClickListener{
            finish()
        }

        date.setOnClickListener {
            showDatePickerDialog()
        }
    }

    private fun areFieldsFilled(): Boolean {
        // Check if all EditText fields are filled
        return campName.text.isNotEmpty() &&
                campMobileNumber.text.isNotEmpty() &&
                campCity.text.isNotEmpty() &&
                campDistrict.text.isNotEmpty() &&
                campAddress.text.isNotEmpty() &&
                campPincode.text.isNotEmpty() &&
                date.text.isNotEmpty()
    }

    private fun saveDataToFirebase() {
        progress.visibility=View.VISIBLE
        val id = "Camps" // Parent node name for camps
        val name = campName.text.toString()
        val mobileNumber = campMobileNumber.text.toString()
        val city = campCity.text.toString()
        val district = campDistrict.text.toString()
        val address = campAddress.text.toString()
        val pincode = campPincode.text.toString()
        val campDate = date.text.toString()
        val daysLeft = numberOfDaysLeftForCamp

        val database = FirebaseDatabase.getInstance()
        val ref = database.getReference(id).child(mobileNumber) // Using phone number as key

        // Create a HashMap to store camp data
        val campData = HashMap<String, Any>()
        campData["name"] = name
        campData["mobilenumber"] = mobileNumber
        campData["city"] = city
        campData["state"] = district
        campData["address"] = address
        campData["pincode"] = pincode
        campData["date"] = campDate
        campData["daysleft"] = daysLeft

        // Save camp data under the phone number
        ref.setValue(campData)
            .addOnSuccessListener {

                Toast.makeText(this, "Camp data added successfully", Toast.LENGTH_SHORT).show()
                progressBar.visibility = View.INVISIBLE
                disableAllEditTexts()
                fetchDataFromRealtimeDatabase()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Failed to add camp data", Toast.LENGTH_SHORT).show()
                progressBar.visibility = View.INVISIBLE
            }
    }

    private fun enableAllEditTexts() {
        editButton.visibility = View.INVISIBLE
        saveButton.visibility = View.VISIBLE
        campName.isEnabled = true
        campMobileNumber.isEnabled = true
        campCity.isEnabled = true
        campDistrict.isEnabled = true
        campAddress.isEnabled = true
        campPincode.isEnabled = true
    }

    private fun disableAllEditTexts() {
        saveButton.isEnabled = false
        campName.isEnabled = false
        campMobileNumber.isEnabled = false
        campCity.isEnabled = false
        campDistrict.isEnabled = false
       // campAddress.isEnabled = false
        campPincode.isEnabled = false
    }

    private fun showDatePickerDialog() {
        val today = Calendar.getInstance()
        val datePicker = DatePickerDialog(
            this,
            { _: DatePicker, year: Int, month: Int, day: Int ->
                val selectedDate = Calendar.getInstance()
                selectedDate.set(year, month, day)

                // Update TextView with selected date
                val formattedDate = "${selectedDate.get(Calendar.DAY_OF_MONTH)}-${selectedDate.get(Calendar.MONTH) + 1}-$year"
                date.text = formattedDate
                // Calculate days left
                val daysLeft = calculateDays(today, selectedDate)
                numberOfDaysLeftForCamp = daysLeft.toString()
            },
            today.get(Calendar.YEAR),
            today.get(Calendar.MONTH),
            today.get(Calendar.DAY_OF_MONTH)
        )

        // Set min date to today
        datePicker.datePicker.minDate = today.timeInMillis

        // Show dialog
        datePicker.show()
    }

    private fun calculateDays(today: Calendar, selectedDate: Calendar): Int {
        val difference = selectedDate.timeInMillis - today.timeInMillis
        return (difference / (1000 * 60 * 60 * 24)).toInt()
    }

    private fun checkInternetConnection() {
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNetworkInfo = connectivityManager.activeNetworkInfo
        val isConnected = activeNetworkInfo != null && activeNetworkInfo.isConnectedOrConnecting
        if (!isConnected) {
            // Show a dialog box indicating no internet connection
            AlertDialog.Builder(this)
                .setTitle("No Internet Connection")
                .setMessage("Please check your internet connection and try again.")
                .setPositiveButton("OK") { dialog, _ ->
                    dialog.dismiss()
                    checkInternetConnection()
                }
                .setCancelable(false)
                .show()
        }
    }

    private fun fetchDataFromRealtimeDatabase() {
        val mutableList: MutableList<String> = mutableListOf()
        val id = "Users" // Your database ID
        val database = FirebaseDatabase.getInstance()
        val ref = database.getReference(id)

        ref.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                snapshot.children.forEach { dataSnapshot ->
                    val number = dataSnapshot.key
                    showToast(dataSnapshot.child("city").value.toString())
                    val userLatitude = dataSnapshot.child("latitude").value?.toString()
                    val userLongitude = dataSnapshot.child("longitude").value?.toString()

                    if (!userLatitude.isNullOrEmpty() && !userLongitude.isNullOrEmpty()) {
                        val mainDistance = 50
                        val distance = calculateDistance(latitudeTxt, longitudeTxt, userLatitude, userLongitude)
                        if (distance <= mainDistance) {
                            val fcmKey = dataSnapshot.child("key").value as String? ?: ""
                            showToast(dataSnapshot.child("city").value.toString())
                            mutableList.add(fcmKey)
                            sendRealtimeNotification(mykey,fcmKey)
                        }
                    }
                }
                //sendNotification(mutableList)
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle error
            }
        })
    }



    private fun sendRealtimeNotification(mykey: String, donorkey: String) {
        val token: String = mykey

        if (token.isNotEmpty()) {
            val jsonObject = JSONObject()
            val notification = JSONObject()
            notification.put("body", "New Blood Camp in"+numberOfDaysLeftForCamp+"days")
            notification.put("title", "Prana")

            jsonObject.put("to", donorkey)
            jsonObject.put("notification", notification)

            callApi(jsonObject)
        } else {
            showToast("FCM token is empty")
        }
    }


    private fun callApi(jsonObject: JSONObject) {
        val JSON: MediaType = "application/json".toMediaType()
        val client = OkHttpClient()
        val url = "https://fcm.googleapis.com/fcm/send"
        val body = RequestBody.create(JSON, jsonObject.toString())
        val request = Request.Builder()
            .url(url)
            .post(body)
            .header(
                "Authorization",
                "Bearer AAAAo-eCFx8:APA91bEr-hX569wXzy-ATCmwBScHYNiXP0BUBbbeBvG7TSL3ZoQmzxS5xyJkvSDvz9rn7cPltEnPQ0kF-rbnEifu39dQ85sB2ZhpK_8vy1hDeQDFdivdIo_t_dXGu17y5KQ_C2FMvpFM"
            ) // Replace YOUR_SERVER_KEY with your Firebase Cloud Messaging server key
            .build()

        // Show progress bar when starting the network request

            progress.visibility = View.VISIBLE


        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                // Hide progress bar when request completes (either success or failure)

                    progress.visibility = View.GONE
                    showToast("Failed to send notification: ${e.message}")

            }

            override fun onResponse(call: Call, response: Response) {
                if (!response.isSuccessful) {
                    // Hide progress bar when request completes (either success or failure)
                    runOnUiThread {
                        progress.visibility = View.GONE
                        showToast("Failed to send notification: ${response.code}")
                    }
                } else {
                    // Hide progress bar when request completes successfully
                    runOnUiThread {
                        progress.visibility = View.GONE
                        showToast("Notification Sent Successfully")
                    }
                }
            }

        })
    }

    private fun showToast(message: String) {
        runOnUiThread {
            Toast.makeText(applicationContext, message, Toast.LENGTH_SHORT).show()
        }
    }

    private fun getLocation() {
        checkLocationPermission()
        val task: Task<Location?> = fusedLocationProviderClient.lastLocation
        if (ActivityCompat.checkSelfPermission(
                this,
                android.Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat
                .checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION), 101)
            return
        }
        task.addOnSuccessListener { location ->
            if (location != null) {
                val latitude = location.latitude
                val longitude = location.longitude

                longitudeTxt = longitude.toString()
                latitudeTxt = latitude.toString()

                val geocoder = Geocoder(this, Locale.getDefault())
                try {
                    val addresses = geocoder.getFromLocation(latitude, longitude, 1)
                    if (addresses != null && addresses.isNotEmpty()) {
                        val address = addresses[0]
                        campAddress.setText(address.getAddressLine(0).toString())
                        campPincode.setText(address.postalCode.toString())
                        campDistrict.setText(address.adminArea)
                        campCity.setText(address.locality)
                        // Display city name instead of district name
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }

    private fun checkLocationPermission() {
        if (ActivityCompat.checkSelfPermission(
                this,
                android.Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(
                this,
                android.Manifest.permission.ACCESS_COARSE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            // Permission already granted
        } else {
            // Permission not granted, request it
            ActivityCompat.requestPermissions(
                this,
                arrayOf(
                    android.Manifest.permission.ACCESS_FINE_LOCATION,
                    android.Manifest.permission.ACCESS_COARSE_LOCATION
                ),
                101
            )
        }
    }

    fun calculateDistance(lat1: String, lon1: String, lat2: String, lon2: String): Double {
        val lat1Rad = Math.toRadians(lat1.toDouble())
        val lon1Rad = Math.toRadians(lon1.toDouble())
        val lat2Rad = Math.toRadians(lat2.toDouble())
        val lon2Rad = Math.toRadians(lon2.toDouble())

        val deltaLat = lat2Rad - lat1Rad
        val deltaLon = lon2Rad - lon1Rad

        val a = Math.sin(deltaLat / 2).pow(2) + Math.cos(lat1Rad) * Math.cos(lat2Rad) * Math.sin(
            deltaLon / 2
        ).pow(2)
        val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))

        // Earth's radius in kilometers
        val earthRadius = 6371.0

        return earthRadius * c
    }
}
