package com.example.prana

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.ConnectivityManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AlertDialog

class LoginActivity : AppCompatActivity() {
    private lateinit var register:TextView
    private lateinit var signInButton:Button

    private lateinit var mobilenumber:EditText
    private lateinit var secretcode:EditText
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        register=findViewById(R.id.RegisternowTextview_loginactivity)
        signInButton=findViewById(R.id.signinbutton_loginactivity)
        mobilenumber=findViewById(R.id.mobilenumber_loginactivity)
        secretcode=findViewById(R.id.secretpassword_loginactivity)

        sharedPreferences = getSharedPreferences("MainActivityData", Context.MODE_PRIVATE)
        val phoneNumber = sharedPreferences.getString("phoneNumber", null)

        val lg=intent.getStringExtra("logout").toString()
        if(lg=="yes"){
            sharedPreferences.edit().remove("phoneNumber").apply()
            sharedPreferences.edit().remove("secretNumber").apply()

        }

        if (phoneNumber != null) {
            val intent = Intent(this, MainActivity::class.java)
            intent.putExtra("phoneNumber", phoneNumber)
            startActivity(intent)
            finish() // Finish LoginActivity to prevent returning back to it when pressing the back button
        }

        register.setOnClickListener {
            val intent = Intent(this, RegistrationActivity::class.java)
            startActivity(intent)
        }

        signInButton.setOnClickListener {
            val phoneNumber = mobilenumber.text.toString()
            val pass = secretcode.text.toString()

            if (phoneNumber.isNotEmpty() && pass.isNotEmpty()) {
                sharedPreferences.edit().putString("phoneNumber", phoneNumber).apply()
                sharedPreferences.edit().putString("secretNumber", pass).apply()
                val intent = Intent(this, ProfileActivity::class.java)
                intent.putExtra("phoneNumber", phoneNumber)
                intent.putExtra("secretNumber", pass)
                startActivity(intent)
            }
        }
    }
    private fun checkInternetConnection() {
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNetworkInfo = connectivityManager.activeNetworkInfo
        val isConnected = activeNetworkInfo != null && activeNetworkInfo.isConnectedOrConnecting
        if (!isConnected) {
            // Show a dialog box indicating no internet connection
            val builder = AlertDialog.Builder(this)
            builder.setTitle("No Internet Connection")
                .setMessage("Please check your internet connection and try again.")
                .setPositiveButton("OK") { dialog, _ ->
                    dialog.dismiss()
                    checkInternetConnection()
                }
                .setCancelable(false)
                .show()
        }
    }
}
