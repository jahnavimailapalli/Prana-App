package com.example.prana

class HospitalClass (
    val name: String,
    val city: String,
    val distance: Double,
    val pincode: String,
    val address: String,
    val mobile:String
)