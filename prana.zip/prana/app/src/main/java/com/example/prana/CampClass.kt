package com.example.prana

class CampClass (
    val address: String,
    val city: String,
    val date: String,
    val daysleft: String,
    val dayleftInt:Int,
    val district:String,
    val mobilenumber:String,
    val name:String,
    val pincode:String,
)