package com.example.prana

data class DonorClass(
    val address:String,
    val age:String,
    val pincode:String,
    val state:String,
    val phnumber:String,
    val name: String,
    val city: String,
    val distance: Double,
    val bloodgroup: String,
    val district:String,
    val fcmkey:String,
    val myfcm:String,
    val hospitalname:String,
    val patientid:String,
    val hospitalnumber:String

)
