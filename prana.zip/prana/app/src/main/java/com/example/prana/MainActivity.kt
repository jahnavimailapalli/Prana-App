package com.example.prana
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.location.Location
import android.net.ConnectivityManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.InputType
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.cardview.widget.CardView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.tasks.Task
import com.google.firebase.database.FirebaseDatabase

class MainActivity : AppCompatActivity() {

    private lateinit var searchblood: Button
    private lateinit var donatebutton: Button
    private lateinit var profilebutton: CardView
    private lateinit var addhos: Button
    private var userMobilemain: String = ""
    private var longitudetxt: String = ""
    private var latitudetxt: String = ""
    private lateinit var progress:ProgressBar

    private  var fcmmain:String=""

    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var fusedLocationProviderClient: FusedLocationProviderClient

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this)
        searchblood = findViewById(R.id.searchbloodbutton)
        donatebutton = findViewById(R.id.donatebutton)
        profilebutton = findViewById(R.id.profilebuttonmainactivity)
        addhos = findViewById(R.id.addcamphospitalbutton)
        progress=findViewById(R.id.progressBar)

        checkInternetConnection()
        checkLocationPermission()

        sharedPreferences = getSharedPreferences("UserMainData", Context.MODE_PRIVATE)
        var phoneNumber = intent.getStringExtra("phoneNumber")
        if (phoneNumber == null) {
            // Phone number not passed from MainActivity, retrieve from UserDetails SharedPreferences
            phoneNumber = sharedPreferences.getString("phoneNumber", null)
        }
        phoneNumber?.let {
            userMobilemain = it
        }

        // Set phoneNumber in UserDetails SharedPreferences
        phoneNumber?.let {
            sharedPreferences.edit().putString("phoneNumber", it).apply()
        }
        fcmmain=intent.getStringExtra("fcmprofile").toString()

        searchblood.setOnClickListener {
            showSearchDialog()

        }

        donatebutton.setOnClickListener {
            val intent = Intent(this, IndividualBloodDonateActivity::class.java)
            intent.putExtra("mymobile", userMobilemain)
            Toast.makeText(this@MainActivity,userMobilemain,Toast.LENGTH_SHORT)
            intent.putExtra("longitudem",longitudetxt)
            Toast.makeText(this@MainActivity,longitudetxt,Toast.LENGTH_SHORT)
            intent.putExtra("latitudem",latitudetxt)
            Toast.makeText(this@MainActivity,latitudetxt,Toast.LENGTH_SHORT)
            startActivity(intent)
        }

        profilebutton.setOnClickListener {
            val intent = Intent(this, ProfileActivity::class.java)
            startActivity(intent)

        }

        addhos.setOnClickListener {
            showDonateDialog()
        }

        // Call getLocation() to retrieve the location coordinates
        getLocation()
    }

    private fun checkLocationPermission() {
        progress.visibility=View.VISIBLE
        if (ActivityCompat.checkSelfPermission(
                this,
                android.Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(
                this,
                android.Manifest.permission.ACCESS_COARSE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {

            // Permission already granted, proceed with location retrieval
            getLocation()
        } else {
            // Permission not granted, request it
            if (ActivityCompat.shouldShowRequestPermissionRationale(
                    this,
                    android.Manifest.permission.ACCESS_FINE_LOCATION
                ) || ActivityCompat.shouldShowRequestPermissionRationale(
                    this,
                    android.Manifest.permission.ACCESS_COARSE_LOCATION
                )
            ) {
                // Explain to the user why the permission is needed
                AlertDialog.Builder(this)
                    .setTitle("Location Permission Needed")
                    .setMessage("This app requires access to your location to provide certain features.")
                    .setPositiveButton("OK") { _, _ ->
                        // Request the permission
                        ActivityCompat.requestPermissions(
                            this,
                            arrayOf(
                                android.Manifest.permission.ACCESS_FINE_LOCATION,
                                android.Manifest.permission.ACCESS_COARSE_LOCATION
                            ),
                            101
                        )
                    }
                    .setNegativeButton("Cancel") { dialog, _ ->
                        dialog.dismiss()
                        // Handle the case where the user cancels the permission request
                    }
                    .create()
                    .show()
            } else {
                // Request the permission without explanation
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(
                        android.Manifest.permission.ACCESS_FINE_LOCATION,
                        android.Manifest.permission.ACCESS_COARSE_LOCATION
                    ),
                    101
                )
            }
        }
    }


    private fun updatelocation() {
        val id = "Users"
        val database = FirebaseDatabase.getInstance()
        val ref = database.getReference(id).child(userMobilemain) // Child node with phone number

        // Create a HashMap to store only the location data
        val locationData = HashMap<String, Any>()
        locationData["longitude"] = longitudetxt
        locationData["latitude"] = latitudetxt

        // Update the location data in the Firebase Realtime Database
        ref.updateChildren(locationData)
            .addOnSuccessListener {
               // Toast.makeText(this, "Location Updated Successfully", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener { e ->
               // Toast.makeText(this, "Failed to update location: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun showDonateDialog() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Who are you?")
        builder.setPositiveButton("hospital") { dialog, which ->
            // Start activity for organisation
            dialogcamp()
        }
        builder.setNegativeButton("camp") { dialog, which ->
            // Start activity for individual
            val intent = Intent(this, CampActivity::class.java)
            intent.putExtra("usermobile",userMobilemain)
            intent.putExtra("mykey",fcmmain)
            startActivity(intent)
        }
        val dialog = builder.create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setTextColor(ContextCompat.getColor(this, R.color.black))
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE)
                .setTextColor(ContextCompat.getColor(this, R.color.black))
        }

        dialog.show()
    }

    @SuppressLint("MissingInflatedId")
    private fun showSearchDialog() {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.bloodsearchdialogview, null)
        val spinnerBloodGroup = dialogView.findViewById<Spinner>(R.id.spinnerBloodGroup)
        val hspspinner=dialogView.findViewById<Spinner>(R.id.hospitalname)
        val buttonSearch = dialogView.findViewById<Button>(R.id.buttonSearch)
        val cancelSearch = dialogView.findViewById<Button>(R.id.cancelSearch)
       val hospitalname=dialogView.findViewById<EditText>(R.id.hspname)
        val patientId=dialogView.findViewById<EditText>(R.id.patientid)
        val hospitalnumber=dialogView.findViewById<EditText>(R.id.hospitalnum)

        val bloodGroups = arrayOf("select a blood group","O-", "O+", "A-", "A+", "B-", "B+", "AB-", "AB+")
        val dilaoghsp= arrayOf("select a hospital","Narayana Hospital " , "Apollo" , "KIMS" , "Medicover" , "Govt General Hospital ", "Others")
       // val spc=dialogView.findViewById<EditText>()
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, bloodGroups)
        val adapterhsp=ArrayAdapter(this,android.R.layout.simple_spinner_item,dilaoghsp)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        adapterhsp.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerBloodGroup.adapter = adapter
        hspspinner.adapter=adapterhsp




        val builder = AlertDialog.Builder(this)
        builder.setView(dialogView)
        val dialog = builder.create()

       // val hname = hspspinner.selectedItem.toString()


        buttonSearch.setOnClickListener {
            val selectedBloodGroup = spinnerBloodGroup.selectedItem.toString()
            val hname = hspspinner.selectedItem.toString()
            if (hname.toLowerCase()=="others"){
                hospitalname.visibility=View.VISIBLE

            }
            else{
                hospitalname.visibility=View.INVISIBLE
            }
            val pd = patientId.text.toString()
            val hnum = hospitalnumber.text.toString()


            // Check if any of the values are null
            if (selectedBloodGroup.isNotEmpty() && hname.isNotEmpty() && pd.isNotEmpty() && hnum.isNotEmpty()&& selectedBloodGroup!="select a blood group" && hname!="select a hospital") {
                if ( hname.toLowerCase()=="others"){
                    hospitalname.visibility=View.VISIBLE
                    val hmn=hospitalname.text.toString()
                    if(hmn.isNotEmpty()){
                        val intent = Intent(this, BloodSearchActivity::class.java)
                        intent.putExtra("mymobile", userMobilemain)
                        intent.putExtra("BLOOD_GROUP", selectedBloodGroup)
                        intent.putExtra("fcmmain", fcmmain)
                        intent.putExtra("longi", longitudetxt)
                        intent.putExtra("lati", latitudetxt)
                        intent.putExtra("hospitalname", hmn)
                        intent.putExtra("patientId", pd)
                        intent.putExtra("hospitalmobile", hnum)
                        startActivity(intent)
                        dialog.dismiss()
                    }
                    else{
                        Toast.makeText(this@MainActivity,"Enter Hospital name",Toast.LENGTH_SHORT).show()
                    }


                }
                else{
                    hospitalname.visibility=View.INVISIBLE
                    Toast.makeText(this@MainActivity,hname,Toast.LENGTH_SHORT).show()
                    val intent = Intent(this, BloodSearchActivity::class.java)
                    intent.putExtra("mymobile", userMobilemain)
                    intent.putExtra("BLOOD_GROUP", selectedBloodGroup)
                    intent.putExtra("fcmmain", fcmmain)
                    intent.putExtra("longi", longitudetxt)
                    intent.putExtra("lati", latitudetxt)
                    intent.putExtra("hospitalname", hname)
                    intent.putExtra("patientId", pd)
                    intent.putExtra("hospitalmobile", hnum)
                    startActivity(intent)
                    dialog.dismiss()
                }
                // Start the new activity and pass the selected blood group
                // Dismiss the dialog after starting the new activity
            } else {
                // Show a toast indicating that all values need to be filled
                Toast.makeText(this, "Please fill all the values", Toast.LENGTH_SHORT).show()
            }
        }


        cancelSearch.setOnClickListener {
            dialog.dismiss() // Dismiss the dialog on cancel button click
        }

        // Set up an OnShowListener to customize button appearance
        dialog.setOnShowListener {
            val positiveButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE)
            val negativeButton = dialog.getButton(AlertDialog.BUTTON_NEGATIVE)

            // Set text color to black
            buttonSearch.setTextColor(ContextCompat.getColor(this, android.R.color.black))
            cancelSearch.setTextColor(ContextCompat.getColor(this, android.R.color.black))

            // Set background to black_button_background drawable
            buttonSearch.setBackgroundResource(R.drawable.black_button_background)
            cancelSearch.setBackgroundResource(R.drawable.black_button_background)
        }

        dialog.show()
    }


    fun dialogcamp() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Select An Action?")

        // Set positive button to "Add Hospital"
        builder.setPositiveButton("Add Hospital") { dialog, which ->
            val intent = Intent(this, HosptitalActivity::class.java)
            startActivity(intent)
        }

        // Set negative button to "Edit an existing"
        builder.setNegativeButton("Edit an existing") { dialog, which ->
            showSecretCodeDialog("Edit an existing")
        }

        // Create the dialog
        val dialog = builder.create()

        // Set up an OnShowListener to customize button appearance
        dialog.setOnShowListener {
            val positiveButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE)
            val negativeButton = dialog.getButton(AlertDialog.BUTTON_NEGATIVE)

            // Set text color to black
            positiveButton.setTextColor(ContextCompat.getColor(this, android.R.color.black))
            negativeButton.setTextColor(ContextCompat.getColor(this, android.R.color.black))

            // Set background to black_button_background drawable
            positiveButton.setBackgroundResource(R.drawable.black_button_background)
            negativeButton.setBackgroundResource(R.drawable.black_button_background)
        }

        dialog.show()
    }


    fun showSecretCodeDialog(action: String) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Enter Secret Code for $action")

        // Set up the input
        val input = EditText(this)
        input.inputType = InputType.TYPE_CLASS_TEXT
        builder.setView(input)

        // Set up the buttons
        builder.setPositiveButton("OK") { dialog, which ->
            val code = input.text.toString()
            // Process the secret code based on the action (add or edit)
            // For example, you can pass the code to respective functions
            if (action == "Add Hospital") {
                // Process code for adding hospital
            } else if (action == "Edit an existing") {
                // Process code for editing existing hospital
                val intent = Intent(this, HosptitalActivity::class.java)
                intent.putExtra("code", code)
                startActivity(intent)
            }
        }

        builder.setNegativeButton("Cancel") { dialog, which ->
            dialog.cancel()
        }

        // Create the dialog
        val dialog = builder.create()

        // Set up an OnShowListener to customize button appearance
        dialog.setOnShowListener {
            val positiveButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE)
            val negativeButton = dialog.getButton(AlertDialog.BUTTON_NEGATIVE)

            // Set text color to black
            positiveButton.setTextColor(ContextCompat.getColor(this, android.R.color.black))
            negativeButton.setTextColor(ContextCompat.getColor(this, android.R.color.black))

            // Set background to black_button_background drawable
            positiveButton.setBackgroundResource(R.drawable.black_button_background)
            negativeButton.setBackgroundResource(R.drawable.black_button_background)
        }

        dialog.show()
    }


    private fun checkInternetConnection() {
        val connectivityManager =
            getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNetworkInfo = connectivityManager.activeNetworkInfo
        val isConnected = activeNetworkInfo != null && activeNetworkInfo.isConnectedOrConnecting
        if (!isConnected) {
            // Show a dialog box indicating no internet connection
            val builder = AlertDialog.Builder(this)
            builder.setTitle("No Internet Connection")
                .setMessage("Please check your internet connection and try again.")
                .setPositiveButton("OK") { dialog, _ ->
                    dialog.dismiss()
                    checkInternetConnection()
                }
                .setCancelable(false)
                .show()
        }
    }

    private fun getLocation() {
        val task: Task<Location?> = fusedLocationProviderClient.lastLocation
        if (ActivityCompat.checkSelfPermission(
                this,
                android.Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat
                .checkSelfPermission(
                    this,
                    android.Manifest.permission.ACCESS_COARSE_LOCATION
                ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this, arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION), 101
            )
            return
        }
        task.addOnSuccessListener { location ->
            if (location != null) {
                val latitude = location.latitude
                val longitude = location.longitude

                longitudetxt = longitude.toString()
                latitudetxt = latitude.toString()

                // Call updatelocation() only after getting the location coordinates
                progress.visibility=View.INVISIBLE
                updatelocation()
            } else {
                //Toast.makeText(applicationContext, "Location not available", Toast.LENGTH_SHORT).show()
                progress.visibility=View.INVISIBLE

            }
        }
    }
}
