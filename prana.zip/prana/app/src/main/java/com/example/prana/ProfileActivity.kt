package com.example.prana
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.net.ConnectivityManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.tasks.Task
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.messaging.FirebaseMessaging
import java.util.Locale
import android.Manifest


class ProfileActivity : AppCompatActivity() {

    private lateinit var username: EditText
    private lateinit var userage: EditText
    private lateinit var usermobilenumber: TextView
    private lateinit var userpincode: EditText
    private lateinit var userbloodgroup: Spinner
    private lateinit var usercity: EditText
    private lateinit var userpassword: EditText
    private lateinit var useradress: EditText
    private lateinit var userstate: EditText
    private lateinit var bigname: TextView
    private lateinit var logout:ImageView
    private var NOTIFICATION_PERMISSION_REQUEST_CODE = 101

    // Buttons
    private lateinit var savebutton: Button
    private lateinit var editbutton: Button

    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var bloodgrp: String
    private lateinit var progress: ProgressBar

    // Location
    private lateinit var fusedLocationProviderClient: FusedLocationProviderClient
    private lateinit var latitudetxt: String
    private lateinit var locationupdate: ImageView
    private lateinit var longitudetxt: String
    private lateinit var mobnumbersav: String
    private var mainFcm: String = ""
    private val bloodGroups = arrayOf(
        "Select Blood Group", "A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"
    )
    private var dataFetched = false
    private var locationPermissionDenied = false

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        username = findViewById(R.id.username_main)
        userage = findViewById(R.id.userage_main)
        usermobilenumber = findViewById(R.id.usermonilenumber_main)
        userpincode = findViewById(R.id.userpincode_main)
        userbloodgroup = findViewById(R.id.userBloodGroup_main)
        usercity = findViewById(R.id.usercity_main)
        userpassword = findViewById(R.id.userpassword_main)
        userstate = findViewById(R.id.userstate_main)
        useradress = findViewById(R.id.useradress_main)
        bigname = findViewById(R.id.prfilebigtextview)
        logout=findViewById(R.id.logout_profile)

        locationupdate = findViewById(R.id.location_profile)
        savebutton = findViewById(R.id.savebutton_main)
        editbutton = findViewById(R.id.editbutton_main)
        progress = findViewById(R.id.progressBar)

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this)

        checkInternetConnection()
        checkAndRequestNotificationPermission()
        getFcmToken()
        sharedPreferences = getSharedPreferences("UserDetailsData", Context.MODE_PRIVATE)
        var phoneNumber = intent.getStringExtra("phoneNumber")
        var secretcodepass = intent.getStringExtra("secretNumber")

        if (phoneNumber == null) {
            // Phone number not passed from MainActivity, retrieve from UserDetails SharedPreferences
            phoneNumber = sharedPreferences.getString("phoneNumber", null)
        }
        phoneNumber?.let {
            usermobilenumber.text = it
        }

        logout.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            intent.putExtra("logout","yes")
            startActivity(intent)
            finish()

        }
        // Set phoneNumber in UserDetails SharedPreferences
        phoneNumber?.let {
            sharedPreferences.edit().putString("phoneNumber", it).apply()
        }

        userpassword.setText(secretcodepass)
        userpassword.isEnabled = false
        mobnumbersav = phoneNumber.toString()

        // Fetch data from Firebase only if it hasn't been fetched previously
        if (!dataFetched) {
            unenable()
            fetchProfile()
        }
        spinner()

        savebutton.setOnClickListener {
            if (validateFields()) {
                addDataToFirebase()
                val intent = Intent(this, MainActivity::class.java)
                intent.putExtra("phoneNumber", phoneNumber)
                intent.putExtra("fcmprofile", mainFcm)
                startActivity(intent)
                finish()
                unenable()
            }
        }

        locationupdate.setOnClickListener {
            getLocation()
            if (validateFields()) {
                addDataToFirebase()
            }
        }

        editbutton.setOnClickListener {
            enableviews()
        }
    }

    private fun validateFields(): Boolean {
        return if (username.text.toString().isNotEmpty() &&
            userage.text.toString().isNotEmpty() &&
            usermobilenumber.text.toString().isNotEmpty() &&
            userpincode.text.toString().isNotEmpty() &&
            bloodgrp.isNotEmpty() && !bloodgrp.equals("Select Blood Group")&&
            usercity.text.toString().isNotEmpty() &&
            userpassword.text.toString().isNotEmpty() &&
            userstate.text.toString().isNotEmpty() &&
            useradress.text.toString().isNotEmpty()
        ) {
            true
        } else {
            Toast.makeText(this, "Please fill in all fields to save", Toast.LENGTH_SHORT).show()
            progress.visibility = View.INVISIBLE // or View.GONE if you want to completely hide it
            false
        }
    }

    private fun enableviews() {
        savebutton.visibility = View.VISIBLE
        username.isEnabled = true
        userage.isEnabled = true
        usercity.isEnabled = true
        userstate.isEnabled = true
        userpassword.isEnabled = true
        useradress.isEnabled = true
        userbloodgroup.isEnabled = true
        editbutton.visibility = View.INVISIBLE
    }

    private fun unenable() {
        savebutton.visibility = View.INVISIBLE
        username.isEnabled = false
        userage.isEnabled = false
        usercity.isEnabled = false
        userstate.isEnabled = false
        userpassword.isEnabled = false
        useradress.isEnabled = false
        userbloodgroup.isEnabled = false
        editbutton.visibility = View.VISIBLE
    }

    private fun addDataToFirebase() {
        progress.visibility = View.VISIBLE
        val id = "Users" // Parent node name
        val phoneNumber = usermobilenumber.text.toString()
        val name = username.text.toString()
        val age = userage.text.toString()
        val city = usercity.text.toString()
        val address = useradress.text.toString()
        val state = userstate.text.toString()
        val password = userpassword.text.toString()
        val pincode = userpincode.text.toString()
        val lat = latitudetxt
        val lon = longitudetxt
        val fcmkey = mainFcm

        val database = FirebaseDatabase.getInstance()
        val ref = database.getReference(id).child(phoneNumber) // Child node with phone number

        val user = HashMap<String, Any>()
        user["name"] = name
        user["bloodgroup"] = bloodgrp
        user["mobilenumber"] = phoneNumber
        user["password"] = password
        user["age"] = age
        user["state"] = state
        user["city"] = city
        user["pincode"] = pincode
        user["address"] = address
        user["longitude"] = lon
        user["latitude"] = lat
        user["key"] = fcmkey

        ref.setValue(user)
            .addOnSuccessListener {
                Toast.makeText(this, "Data Saved successfully", Toast.LENGTH_SHORT).show()
                progress.visibility = View.INVISIBLE
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "failed", Toast.LENGTH_SHORT).show()
                progress.visibility = View.INVISIBLE
            }
    }

    private fun fetchProfile() {
        val id = "Users"
        val phoneNumber = mobnumbersav
        progress.visibility = View.VISIBLE
        val database = FirebaseDatabase.getInstance()
        val ref = database.getReference(id).child(phoneNumber)
        ref.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    val user = snapshot.value as? Map<*, *>

                    val name = user?.get("name") as? String ?: ""
                    val phone = user?.get("mobilenumber") as? String ?: ""
                    val bg = user?.get("bloodgroup") as? String ?: ""
                    val pass = user?.get("password") as? String ?: ""
                    val age = user?.get("age") as? String ?: ""
                    val st = user?.get("state") as? String ?: ""
                    val ct = user?.get("city") as? String ?: ""
                    val pin = user?.get("pincode") as? String ?: ""
                    val add = user?.get("address") as? String ?: ""

                    username.setText(name)
                    usermobilenumber.setText(phone)
                    val position = bloodGroups.indexOf(bg)
                    userbloodgroup.setSelection(position)
                    userpassword.setText(pass)
                    userage.setText(age)
                    userstate.setText(st)
                    usercity.setText(ct)
                    userpincode.setText(pin)
                    useradress.setText(add)
                    progress.visibility = View.INVISIBLE
                } else {
                    progress.visibility = View.INVISIBLE
                    Toast.makeText(
                        this@ProfileActivity,
                        "Unable To Find User",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onCancelled(error: DatabaseError) {
                progress.visibility = View.INVISIBLE
                Toast.makeText(
                    this@ProfileActivity,
                    "Failed to fetch data: ${error.message}",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })
    }

    private fun spinner() {
        val adapter = ArrayAdapter<String>(
            this, android.R.layout.simple_spinner_item, bloodGroups
        )
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        userbloodgroup.adapter = adapter

        userbloodgroup.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val selectedBloodGroup = bloodGroups[position]
                bloodgrp = selectedBloodGroup
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                // Do nothing
            }
        }
    }

    private fun getLocation() {
        val task: Task<Location?> = fusedLocationProviderClient.lastLocation
        if (ActivityCompat.checkSelfPermission(
                this,
                android.Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat
                .checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
        ) {
            // Request location permission
            requestLocationPermission()
            return
        }
        task.addOnSuccessListener { location ->
            if (location != null) {
                val latitude = location.latitude
                val longitude = location.longitude

                longitudetxt = longitude.toString()
                latitudetxt = latitude.toString()

                val geocoder = Geocoder(this, Locale.getDefault())
                try {
                    val addresses = geocoder.getFromLocation(latitude, longitude, 1)
                    if (addresses != null && addresses.isNotEmpty()) {
                        val address = addresses[0]
                        useradress.setText(address.getAddressLine(0).toString())
                        userpincode.setText(address.postalCode.toString())
                        userstate.setText(address.adminArea)
                        usercity.setText(address.locality)
                    } else {
                        Toast.makeText(this, "No address found", Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                    Toast.makeText(this, "Error getting address: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(applicationContext, "Location not available", Toast.LENGTH_SHORT).show()
            }
        }
    }


    private fun requestLocationPermission() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(
                android.Manifest.permission.ACCESS_FINE_LOCATION,
                android.Manifest.permission.ACCESS_COARSE_LOCATION
            ),
            101
        )
    }

    private fun checkInternetConnection() {
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNetworkInfo = connectivityManager.activeNetworkInfo
        val isConnected = activeNetworkInfo != null && activeNetworkInfo.isConnectedOrConnecting
        if (!isConnected) {
            // Show a dialog box indicating no internet connection
            val builder = AlertDialog.Builder(this)
            builder.setTitle("No Internet Connection")
                .setMessage("Please check your internet connection and try again.")
                .setPositiveButton("OK") { dialog, _ ->
                    dialog.dismiss()
                    checkInternetConnection()
                }
                .setCancelable(false)
                .show()
        } else {
            checkLocationPermission()
        }
    }

    private fun getFcmToken() {
        FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
            if (task.isSuccessful) {
                val token: String? = task.result
                token?.let {
                    mainFcm = it
                }
            } else {
                // Handle error
            }
        }
    }

    private fun checkLocationPermission() {
        val locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            // Location services are disabled, prompt user to enable them
            AlertDialog.Builder(this)
                .setTitle("Location Services Required")
                .setMessage("Please enable location services to use this app.")
                .setPositiveButton("OK") { _, _ ->
                    // Open location settings to allow the user to enable location services
                    startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
                }
                .setNegativeButton("Cancel") { dialog, _ ->
                    dialog.dismiss()
                    // Handle the case where the user cancels enabling location services
                }
                .create()
                .show()
        } else {
            // Location services are enabled, proceed with checking location permissions
            if (ActivityCompat.checkSelfPermission(
                    this,
                    android.Manifest.permission.ACCESS_FINE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(
                    this,
                    android.Manifest.permission.ACCESS_COARSE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED
            ) {
                // Permission already granted, proceed with location retrieval
                getLocation()
            } else {
                // Permission not granted, request it
                if (ActivityCompat.shouldShowRequestPermissionRationale(
                        this,
                        android.Manifest.permission.ACCESS_FINE_LOCATION
                    ) || ActivityCompat.shouldShowRequestPermissionRationale(
                        this,
                        android.Manifest.permission.ACCESS_COARSE_LOCATION
                    )
                ) {
                    // Explain to the user why the permission is needed
                    AlertDialog.Builder(this)
                        .setTitle("Location Permission Needed")
                        .setMessage("This app requires access to your location to provide certain features.")
                        .setPositiveButton("OK") { _, _ ->
                            // Request the permission
                            ActivityCompat.requestPermissions(
                                this,
                                arrayOf(
                                    android.Manifest.permission.ACCESS_FINE_LOCATION,
                                    android.Manifest.permission.ACCESS_COARSE_LOCATION
                                ),
                                101
                            )
                        }
                        .setNegativeButton("Cancel") { dialog, _ ->
                            dialog.dismiss()
                            // Handle the case where the user cancels the permission request
                        }
                        .create()
                        .show()
                } else {
                    // Request the permission without explanation
                    ActivityCompat.requestPermissions(
                        this,
                        arrayOf(
                            android.Manifest.permission.ACCESS_FINE_LOCATION,
                            android.Manifest.permission.ACCESS_COARSE_LOCATION
                        ),
                        101
                    )
                }
            }
        }
    }
    private fun checkAndRequestNotificationPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            // Permission is not granted
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.POST_NOTIFICATIONS)) {
                showExplanationDialog()
            } else {
                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), NOTIFICATION_PERMISSION_REQUEST_CODE)
            }
        }
    }

    private fun showExplanationDialog() {
        AlertDialog.Builder(this)
            .setTitle("Notification Permission Needed")
            .setMessage("This app needs permission to send you notifications about important updates and features. Granting this permission will allow you to receive timely information directly within the app.")
            .setPositiveButton("OK") { _, _ ->
                // Prompt the user once explanation has been shown
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), NOTIFICATION_PERMISSION_REQUEST_CODE)
            }
            .create()
            .show()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == NOTIFICATION_PERMISSION_REQUEST_CODE) {
            if ((grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                // Permission was granted
                // You can now send notifications
            } else {
                // Permission denied
                // Disable the functionality that depends on this permission.
            }
        }
    }


    private fun showPermissionDeniedDialog() {
        AlertDialog.Builder(this)
            .setTitle("Location Permission Denied")
            .setMessage("Please grant location permission to use this feature.")
            .setPositiveButton("OK") { dialog, _ ->
                dialog.dismiss()
                finish() // Close the activity or handle accordingly
            }
            .setCancelable(false)
            .show()
    }

}



