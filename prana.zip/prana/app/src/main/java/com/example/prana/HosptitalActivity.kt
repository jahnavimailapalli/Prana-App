package com.example.prana

import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.net.ConnectivityManager
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.tasks.Task
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import java.util.Locale

class HosptitalActivity : AppCompatActivity() {

    private lateinit var hospitalName: EditText
    private lateinit var hospitalMobileNumber: EditText
    private lateinit var hospitalCity: EditText
    private lateinit var hospitalAddress: EditText
    private lateinit var hospitalPincode: EditText
    private lateinit var saveButtonHospital: Button
    private lateinit var editButtonHospital: Button
    private lateinit var hospitalCode: EditText
    private lateinit var hospitalState: EditText
    private lateinit var latitudeTxt: String
    private lateinit var longitudeTxt: String
    private lateinit var fusedLocationProviderClient: FusedLocationProviderClient
    private lateinit var progressBar: ProgressBar
    private lateinit var closebutton:CardView

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_hosptital)

        // Initialize views
        hospitalName = findViewById(R.id.name_hospital)
        hospitalMobileNumber = findViewById(R.id.mobilenumber_hospital)
        hospitalCity = findViewById(R.id.city_hospital)
        hospitalAddress = findViewById(R.id.adress_hospital)
        hospitalPincode = findViewById(R.id.pincode_hospital)
        saveButtonHospital = findViewById(R.id.savebutton_hospital)
        editButtonHospital = findViewById(R.id.editbutton_hospital)
        progressBar = findViewById(R.id.progressBarhospital)
        hospitalCode = findViewById(R.id.hospital_pass)
        hospitalState = findViewById(R.id.state_hospital)
        closebutton=findViewById(R.id.backbutton_hospital)

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this)

        checkInternetConnection()
        getLocation()

        saveButtonHospital.setOnClickListener {
            // Check if all necessary fields are filled
            if (areFieldsFilled()) {
                // If data is valid, save to Firebase
                saveDataToFirebase()
            } else {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            }
        }
        closebutton.setOnClickListener {
            finish()
        }

        val passcode = intent.getStringExtra("code")
        if (passcode != null) {
            fetchHospitalProfile(passcode)
        }

        editButtonHospital.setOnClickListener {
            enableAllEditTexts()
        }
    }

    private fun fetchHospitalProfile(passcode: String) {
        val id = "Hospitals" // Parent node name for hospitals
        val database = FirebaseDatabase.getInstance()
        val ref = database.getReference(id).child(passcode)

        ref.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    val hospital = snapshot.value as Map<*, *>
                    hospitalName.setText(hospital["name"] as String?)
                    hospitalMobileNumber.setText(hospital["mobilenumber"] as String?)
                    hospitalCity.setText(hospital["city"] as String?)
                    hospitalAddress.setText(hospital["address"] as String?)
                    hospitalPincode.setText(hospital["pincode"] as String?)
                    hospitalCode.setText(hospital["password"] as String?)
                    progressBar.visibility = View.INVISIBLE
                } else {
                    progressBar.visibility = View.INVISIBLE
                    Toast.makeText(this@HosptitalActivity, "Hospital data not found", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onCancelled(error: DatabaseError) {
                progressBar.visibility = View.INVISIBLE
                Toast.makeText(this@HosptitalActivity, "Failed to fetch hospital data: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun areFieldsFilled(): Boolean {
        // Check if all EditText fields are filled
        return hospitalName.text.toString().isNotEmpty() &&
                hospitalMobileNumber.text.toString().isNotEmpty() &&
                hospitalCity.text.toString().isNotEmpty() &&
                hospitalAddress.text.toString().isNotEmpty() &&
                hospitalPincode.text.toString().isNotEmpty()
    }

    private fun saveDataToFirebase() {
        progressBar.visibility = View.VISIBLE
        saveButtonHospital.visibility = View.INVISIBLE
        val id = "Hospitals" // Parent node name for hospitals
        val name = hospitalName.text.toString()
        val mobileNumber = hospitalMobileNumber.text.toString()
        val city = hospitalCity.text.toString()
        val address = hospitalAddress.text.toString()
        val pincode = hospitalPincode.text.toString()
        val password = hospitalCode.text.toString()
        val lat = latitudeTxt
        val lon = longitudeTxt

        val database = FirebaseDatabase.getInstance()
        val ref = database.getReference(id).child(password) // Using phone number as key

        // Create a HashMap to store hospital data
        val hospitalData = HashMap<String, Any>()
        hospitalData["name"] = name
        hospitalData["mobilenumber"] = mobileNumber
        hospitalData["city"] = city
        hospitalData["address"] = address
        hospitalData["pincode"] = pincode
        hospitalData["password"] = password
        hospitalData["latitude"] = lat
        hospitalData["longitude"] = lon

        // Save hospital data under the phone number
        ref.setValue(hospitalData)
            .addOnSuccessListener {
                Toast.makeText(this, "Hospital data added successfully", Toast.LENGTH_SHORT).show()
                progressBar.visibility = View.INVISIBLE
                disableAllEditTexts()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Failed to add hospital data", Toast.LENGTH_SHORT).show()
                progressBar.visibility = View.INVISIBLE
            }
    }

    private fun enableAllEditTexts() {
        editButtonHospital.visibility = View.INVISIBLE
        editButtonHospital.isEnabled = false
        saveButtonHospital.visibility = View.VISIBLE
        saveButtonHospital.isEnabled=true
        hospitalName.isEnabled = true
        hospitalMobileNumber.isEnabled = true
        hospitalCity.isEnabled = true
        hospitalAddress.isEnabled = true
        hospitalPincode.isEnabled = true
        hospitalCode.isEnabled = true
    }

    private fun disableAllEditTexts() {
        saveButtonHospital.visibility = View.INVISIBLE
        saveButtonHospital.isEnabled=false
        editButtonHospital.visibility = View.VISIBLE
        editButtonHospital.isEnabled=true
        hospitalName.isEnabled = false
        hospitalMobileNumber.isEnabled = false
        hospitalCity.isEnabled = false
        //hospitalAddress.isEnabled = false
        hospitalPincode.isEnabled = false
        hospitalCode.isEnabled = false
    }

    private fun getLocation() {
        val task: Task<Location?> = fusedLocationProviderClient.lastLocation
        if (ActivityCompat.checkSelfPermission(
                this,
                android.Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat
                .checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION), 101)
            return
        }
        task.addOnSuccessListener { location ->
            if (location != null) {
                val latitude = location.latitude
                val longitude = location.longitude

                longitudeTxt = longitude.toString()
                latitudeTxt = latitude.toString()

                val geocoder = Geocoder(this, Locale.getDefault())
                try {
                    val addresses = geocoder.getFromLocation(latitude, longitude, 1)
                    if (addresses != null && addresses.isNotEmpty()) {
                        val address = addresses[0]
                        hospitalAddress.setText(address.getAddressLine(0))
                        hospitalPincode.setText(address.postalCode)
                        hospitalState.setText(address.adminArea)
                        hospitalCity.setText(address.locality)
                        //enablity()
                    } else {
                        Toast.makeText(this, "No address found", Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                    Toast.makeText(this, "Error getting address: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(applicationContext, "Location not available", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun enablity() {
        hospitalAddress.isEnabled = false
        hospitalCity.isEnabled = false
        hospitalState.isEnabled = false
        hospitalPincode.isEnabled = false
    }
    private fun checkInternetConnection() {
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNetworkInfo = connectivityManager.activeNetworkInfo
        val isConnected = activeNetworkInfo != null && activeNetworkInfo.isConnectedOrConnecting
        if (!isConnected) {
            // Show a dialog box indicating no internet connection
            val builder = AlertDialog.Builder(this)
            builder.setTitle("No Internet Connection")
                .setMessage("Please check your internet connection and try again.")
                .setPositiveButton("OK") { dialog, _ ->
                    dialog.dismiss()
                    checkInternetConnection()
                }
                .setCancelable(false)
                .show()
        }
    }
}
