package com.example.prana
//package com.example.prana
import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.telephony.SmsManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Filter
import android.widget.Filterable
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import org.json.JSONObject
import java.io.IOException

class BloodSearchAdapter(private var donorsList: List<DonorClass>) :
    RecyclerView.Adapter<BloodSearchAdapter.ViewHolder>(), Filterable {

    private var donorsListFull: List<DonorClass> = donorsList
    private lateinit var context: Context
    private lateinit var progressbar: ProgressBar
    private val PERMISSION_REQUEST_CODE = 123
    private val mainHandler = Handler(Looper.getMainLooper())

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val textViewName: TextView = itemView.findViewById(R.id.textViewName)
        val textViewBloodGroup: TextView = itemView.findViewById(R.id.textViewBloodGroup)
        val textViewDistance: TextView = itemView.findViewById(R.id.textViewdistance)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        context = parent.context
        val view = LayoutInflater.from(context).inflate(R.layout.donorsitems, parent, false)
        val viewHolder = ViewHolder(view)

        // Set click listener for opening dialog on item click
        view.setOnClickListener {
            val position = viewHolder.adapterPosition
            if (position != RecyclerView.NO_POSITION) {
                // Get the donor at the clicked position
                val donor = donorsList[position]

                // Open dialog with custom layout
                showDialog(donor)
            }
        }
        return viewHolder
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val donor = donorsList[position]
        holder.textViewName.text = donor.name
        holder.textViewBloodGroup.text = donor.bloodgroup
        val roundedDistance = donor.distance.toInt()
        holder.textViewDistance.text = "$roundedDistance km"
    }

    override fun getItemCount(): Int {
        return donorsList.size
    }

    override fun getFilter(): Filter {
        return object : Filter() {
            override fun performFiltering(constraint: CharSequence?): FilterResults {
                val filteredList = ArrayList<DonorClass>()
                if (constraint.isNullOrEmpty()) {
                    filteredList.addAll(donorsListFull)
                } else {
                    val filterPattern = constraint.toString().toLowerCase().trim()
                    for (item in donorsListFull) {
                        if (item.name.toLowerCase().contains(filterPattern)) {
                            filteredList.add(item)
                        }
                    }
                }
                val filterResults = FilterResults()
                filterResults.values = filteredList
                return filterResults
            }

            override fun publishResults(constraint: CharSequence?, results: FilterResults?) {
                donorsList = results?.values as List<DonorClass>
                notifyDataSetChanged()
            }
        }
    }

    @SuppressLint("MissingInflatedId")
    private fun showDialog(donor: DonorClass) {
        // Inflate your custom dialog layout
        val dialogView = LayoutInflater.from(context).inflate(R.layout.donorprofileview, null)

        // Customize your dialog view (e.g., set donor details)
        val donorname = dialogView.findViewById<EditText>(R.id.donornameprofile)
        donorname.setText(donor.name)
        progressbar = dialogView.findViewById(R.id.progressbar)

        val donorage = dialogView.findViewById<EditText>(R.id.donorageprofile)
        donorage.setText(donor.age)

        val donormobile = dialogView.findViewById<EditText>(R.id.donormobileprofile)
        donormobile.setText(donor.phnumber)

        val donorbloodgroup = dialogView.findViewById<EditText>(R.id.donorbloodgroupprofile)
        donorbloodgroup.setText(donor.bloodgroup)

        val donorcity = dialogView.findViewById<EditText>(R.id.donorcityprofile)
        donorcity.setText(donor.city)

        val sendNotification = dialogView.findViewById<Button>(R.id.sendnotificationtodonor)
        sendNotification.setOnClickListener {
            val donorkey = donor.fcmkey
            val mykey = donor.myfcm
            val message = "Hello"
            val hospnm = donor.hospitalname
            val patid = donor.patientid
            val hospphn = donor.hospitalnumber
            val donormobile = donor.phnumber
            sendRealtimeNotification(mykey, donorkey, hospnm, patid, hospphn, donormobile)
            // You can replace this with the message you want to send
        }

        // Create and show the dialog
        val builder = AlertDialog.Builder(context)
        builder.setView(dialogView)
        builder.setPositiveButton("Close") { dialog, _ ->
            dialog.dismiss()
        }
        val dialog = builder.create()
        dialog.show()
    }

    private fun sendRealtimeNotification(
        mykey: String,
        donorkey: String,
        hospitalName: String,
        patientId: String,
        hospitalNumber: String,
        donormobile: String
    ) {
        val token: String = mykey

        if (token.isNotEmpty()) {
            val jsonObject = JSONObject()
            val notification = JSONObject()
            notification.put(
                "body",
                "Someone  from " + patientId + " Hospital Needs Blood And Viewed Your Profile"
            )
            notification.put("title", "Prana Be A Life Line")

            jsonObject.put("to", donorkey)
            jsonObject.put("notification", notification)

            callApi(jsonObject, donormobile, hospitalName, patientId, hospitalNumber)
        } else {
            showToast("FCM token is empty")
        }
    }


    private fun callApi(
        jsonObject: JSONObject,
        donormobile: String,
        hospitalName: String,
        hospitalNumber: String,
        patientId: String
    ) {
        val JSON: MediaType = "application/json".toMediaType()
        val client = OkHttpClient()
        val url = "https://fcm.googleapis.com/fcm/send"
        val body = RequestBody.create(JSON, jsonObject.toString())
        val request = Request.Builder()
            .url(url)
            .post(body)
            .header(
                "Authorization",
                "Bearer AAAAo-eCFx8:APA91bEr-hX569wXzy-ATCmwBScHYNiXP0BUBbbeBvG7TSL3ZoQmzxS5xyJkvSDvz9rn7cPltEnPQ0kF-rbnEifu39dQ85sB2ZhpK_8vy1hDeQDFdivdIo_t_dXGu17y5KQ_C2FMvpFM"
            ) // Replace YOUR_SERVER_KEY with your Firebase Cloud Messaging server key
            .build()

        // Show progress bar when starting the network request
        mainHandler.post {
            progressbar.visibility = View.VISIBLE
        }

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                // Hide progress bar when request completes (either success or failure)
                mainHandler.post {
                    progressbar.visibility = View.GONE
                    showToast("Failed to send notification: ${e.message}")
                }
            }

            override fun onResponse(call: Call, response: Response) {
                if (!response.isSuccessful) {
                    // Hide progress bar when request completes (either success or failure)
                    mainHandler.post {
                        progressbar.visibility = View.GONE
                        showToast("Failed to send notification: ${response.code}")
                    }
                } else {
                    // Hide progress bar when request completes successfully
                    mainHandler.post {
                        checksmsPermission(donormobile, hospitalName, hospitalNumber, patientId)
                        sendWhatsAppMessage(donormobile, hospitalName, hospitalNumber, patientId)
                        progressbar.visibility = View.GONE
                        showToast("Notification Sent Sucessfully")


                    }
                }
            }
        })
    }

    private fun showToast(message: String) {
        // Ensure the UI operation is performed on the main thread
        // Toasts must be shown on the main thread

        mainHandler.post {
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
        }
    }

    private fun sendWhatsAppMessage(
        phoneNumber: String,
        hospitalName: String,
        hospitalNumber: String,
        patientId: String
    ) {
        val ph = "91" + phoneNumber
        val message = "Hello,\n\n" +
                "You have been matched with a potential blood donor. Your help is urgently needed for blood donation.\n\n" +
                "Hospital: *$hospitalName*\n" +
                "Patient ID: *$patientId*\n" +
                "Hospital Mobile: *$hospitalNumber*"
        val uri = Uri.parse("https://api.whatsapp.com/send?phone=$ph&text=${Uri.encode(message)}")
        val intent = Intent(Intent.ACTION_VIEW, uri)
        context.startActivity(intent)
    }

    private fun sendSms(
        phoneNumber: String,
        hospitalName: String,
        hospitalNumber: String,
        patientId: String
    ) {
        val ph = "91" + phoneNumber
        val message = "Hello,\n\n" +
                "You have been matched with a potential blood donor. Your help is urgently needed for blood donation.\n\n" +
                "Hospital: *$hospitalName*\n" +
                "Patient ID: *$patientId*\n" +
                "Hospital Mobile: *$hospitalNumber*"
        val uri = Uri.parse("https://api.whatsapp.com/send?phone=$ph&text=${Uri.encode(message)}")
        val intent = Intent(Intent.ACTION_VIEW, uri)
        context.startActivity(intent)
    }

    private fun checksmsPermission(
        phoneNumber: String,
        hospitalName: String,
        hospitalNumber: String,
        patientId: String
    ) {
        if (ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.SEND_SMS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            // Permission is not granted, request it
            ActivityCompat.requestPermissions(
                context as Activity,
                arrayOf(Manifest.permission.SEND_SMS),
                PERMISSION_REQUEST_CODE
            )
        } else {
            // Permission is granted, send SMS
            sendSmsMessage(phoneNumber, hospitalName)
        }
    }

    private fun sendSmsMessage(phoneNumber: String, message: String) {
        try {
            val smsManager = SmsManager.getDefault()
            smsManager.sendTextMessage(phoneNumber, null, message, null, null)
            Toast.makeText(context, "SMS sent successfully", Toast.LENGTH_SHORT).show()
        } catch (ex: Exception) {
            Toast.makeText(context, "SMS sending failed", Toast.LENGTH_SHORT).show()
            ex.printStackTrace()
        }
    }
}



