package com.example.prana

object Constants {
    var FCM_KEY: String = ""

    fun setFCMKey(key: String) {
        FCM_KEY = key
    }
}