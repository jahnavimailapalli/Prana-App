package com.example.prana
import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Filter
import android.widget.Filterable
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.prana.HospitalClass
import com.example.prana.R

class HospitalAdapter(private var hospitalList: List<HospitalClass>) : RecyclerView.Adapter<HospitalAdapter.HospitalViewHolder>(),
    Filterable {

    private var hospitalListFull: List<HospitalClass> = hospitalList.toList()
    inner class HospitalViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val hospitalNameTextView: TextView = itemView.findViewById(R.id.hospital_name_item)
        val hospitalAddressTextView: TextView = itemView.findViewById(R.id.hospital_city_item)
        val distanceTextView: TextView = itemView.findViewById(R.id.distance)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HospitalViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.hospitalitem, parent, false)
        val viewHolder = HospitalViewHolder(itemView)
        itemView.setOnClickListener {
            val position = viewHolder.adapterPosition
            if (position != RecyclerView.NO_POSITION) {
                // Get the donor at the clicked position
                val hospital = hospitalList[position]

                // Open dialog with custom layout
                showDialog(itemView.context, hospital)
            }
        }
        return viewHolder
    }

    override fun onBindViewHolder(holder: HospitalViewHolder, position: Int) {
        val currentItem = hospitalList[position]
        holder.hospitalNameTextView.text = currentItem.name
        holder.hospitalAddressTextView.text = currentItem.city

        // Round the distance to the nearest integer
        val roundedDistance = currentItem.distance.toInt()
        holder.distanceTextView.text = "$roundedDistance km"
    }

    override fun getItemCount() = hospitalList.size

    @SuppressLint("MissingInflatedId")
    private fun showDialog(context: Context, donor: HospitalClass) {
        // Inflate your custom dialog layout
        val dialogView = LayoutInflater.from(context).inflate(R.layout.hospital_view, null)

        // Customize your dialog view (e.g., set donor details)
        val hospitalname=dialogView.findViewById<EditText>(R.id.hospitalnameview)
        hospitalname.setText("Name: "+donor.name)

        val hospitalmobile=dialogView.findViewById<EditText>(R.id.hospitalmobilenumview)
        hospitalmobile.setText(donor.mobile)

        val hospitalcity=dialogView.findViewById<EditText>(R.id.hospitalcityview)
        hospitalcity.setText("city: "+donor.city)

        val hospitaladdress=dialogView.findViewById<EditText>(R.id.hospitaladressview)
        hospitaladdress.setText("address: "+donor.address)



        val hospitalpincode=dialogView.findViewById<EditText>(R.id.hospitalpincodeview)
        hospitalpincode.setText("pincode: "+donor.pincode)

        val displayMetrics = context.resources.displayMetrics
        val dialogWidth = (displayMetrics.widthPixels * 0.9).toInt() // 90% of screen width
        val dialogHeight = (displayMetrics.heightPixels * 0.9).toInt() // 90% of screen height
        dialogView.layoutParams = ViewGroup.LayoutParams(dialogWidth, dialogHeight)
        hospitalname.isEnabled=false
        hospitalcity.isEnabled=false
        hospitaladdress.isEnabled=false
        hospitalpincode.isEnabled=false

        // Create and show the dialog
        val builder = AlertDialog.Builder(context)
        builder.setView(dialogView)
        builder.setPositiveButton("Close") { dialog, _ ->
            dialog.dismiss()
        }
        val dialog = builder.create()
        dialog.setOnShowListener {
            val positiveButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE)
            val negativeButton = dialog.getButton(AlertDialog.BUTTON_NEGATIVE)

            // Set text color to black
            positiveButton.setTextColor(ContextCompat.getColor(context, android.R.color.black))
            negativeButton.setTextColor(ContextCompat.getColor(context, android.R.color.black))

            // Set background to black_button_background drawable
            positiveButton.setBackgroundResource(R.drawable.black_button_background)
            negativeButton.setBackgroundResource(R.drawable.black_button_background)
        }
        dialog.show()
    }
    override fun getFilter(): Filter {
        return object : Filter() {
            override fun performFiltering(constraint: CharSequence?): FilterResults {
                val filteredList = mutableListOf<HospitalClass>()

                if (constraint == null || constraint.isEmpty()) {
                    filteredList.addAll(hospitalListFull)
                } else {
                    val filterPattern = constraint.toString().toLowerCase().trim()

                    for (item in hospitalListFull) {
                        if (item.name.toLowerCase().contains(filterPattern)) {
                            filteredList.add(item)
                        }
                    }
                }

                return FilterResults().apply { values = filteredList }
            }

            @SuppressWarnings("unchecked")
            override fun publishResults(constraint: CharSequence?, results: FilterResults?) {
                hospitalList = results?.values as List<HospitalClass>
                notifyDataSetChanged()
            }
        }
    }




}
