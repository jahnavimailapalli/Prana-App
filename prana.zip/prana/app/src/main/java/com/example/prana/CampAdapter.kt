package com.example.prana
import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Filter
import android.widget.Filterable
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.prana.CampClass
import com.example.prana.R

class CampAdapter(private var campList: List<CampClass>) : RecyclerView.Adapter<CampAdapter.CampViewHolder>(),
    Filterable {
    private var campListFull: List<CampClass> = ArrayList(campList)
    inner class CampViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val campNameTextView: TextView = itemView.findViewById(R.id.camp_name_item)
        val campdateTextView: TextView = itemView.findViewById(R.id.camp_date_item)
        val campdaysleftTextView: TextView = itemView.findViewById(R.id.daysleft)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CampViewHolder{
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.campitem, parent, false)
        val viewHolder = CampViewHolder(itemView)
        itemView.setOnClickListener {
            val position = viewHolder.adapterPosition
            if (position != RecyclerView.NO_POSITION) {
                // Get the donor at the clicked position
                val camp = campList[position]

                // Open dialog with custom layout
                showDialog(itemView.context, camp)
            }
        }
        return viewHolder
    }

    override fun onBindViewHolder(holder: CampViewHolder, position: Int) {
        val currentItem = campList[position]
        holder.campNameTextView.text = currentItem.name
        holder.campdateTextView.text = currentItem.date

        // Round the distance to the nearest integer
        holder.campdaysleftTextView.text = "In ${currentItem.daysleft} days "
    }

    override fun getItemCount() = campList.size

    @SuppressLint("MissingInflatedId")
    private fun showDialog(context: Context, donor: CampClass) {
        // Inflate your custom dialog layout
        val dialogView = LayoutInflater.from(context).inflate(R.layout.activity_camp, null)

        val campButton=dialogView.findViewById<Button>(R.id.saveandnotifubutton_camp)
        campButton.visibility=View.INVISIBLE

        val backarrow=dialogView.findViewById<ImageView>(R.id.backarrow_profile)
        backarrow.visibility=View.INVISIBLE

        // Customize your dialog view (e.g., set donor details)
        val campname=dialogView.findViewById<EditText>(R.id.name_camp)
        campname.setText("Name:"+donor.name)

        val campmobile=dialogView.findViewById<EditText>(R.id.mobilenumber_camp)
        campmobile.setText("Mobile:"+donor.mobilenumber)

        val campcity=dialogView.findViewById<EditText>(R.id.city_camp)
       campcity.setText("city:"+donor.city)

        val camadress=dialogView.findViewById<EditText>(R.id.adress_camp)
        camadress.setText("adress:"+donor.address)





        val camppincode=dialogView.findViewById<EditText>(R.id.pincode_camp)
        camppincode.setText("pincode:"+donor.pincode)

        val campdate=dialogView.findViewById<TextView>(R.id.date_camp)
        campdate.text="date:"+donor.date

        val district=dialogView.findViewById<EditText>(R.id.district_camp)
        district.setText("district:"+donor.district)

        val displayMetrics = context.resources.displayMetrics
        val dialogWidth = (displayMetrics.widthPixels * 0.9).toInt() // 90% of screen width
        val dialogHeight = (displayMetrics.heightPixels * 0.9).toInt() // 90% of screen height
        dialogView.layoutParams = ViewGroup.LayoutParams(dialogWidth, dialogHeight)
        campname.isEnabled=false
        campcity.isEnabled=false
        camadress.isEnabled=false
        campmobile.isEnabled=false
        camppincode.isEnabled=false
        campdate.isEnabled=false
        district.isEnabled=false


        // Create and show the dialog
        val builder = AlertDialog.Builder(context)
        builder.setView(dialogView)
        builder.setPositiveButton("Close") { dialog, _ ->
            dialog.dismiss()
        }

        val dialog = builder.create()
        dialog.setOnShowListener {
            val positiveButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE)
            val negativeButton = dialog.getButton(AlertDialog.BUTTON_NEGATIVE)

            // Set text color to black
            positiveButton.setTextColor(ContextCompat.getColor(context, android.R.color.black))
            negativeButton.setTextColor(ContextCompat.getColor(context, android.R.color.black))

            // Set background to black_button_background drawable
            positiveButton.setBackgroundResource(R.drawable.black_button_background)
            negativeButton.setBackgroundResource(R.drawable.black_button_background)
        }
        dialog.show()
    }

    override fun getFilter(): Filter {
        return object : Filter() {
            override fun performFiltering(constraint: CharSequence?): FilterResults {
                val filteredList = mutableListOf<CampClass>()

                if (constraint == null || constraint.isEmpty()) {
                    filteredList.addAll(campListFull)
                } else {
                    val filterPattern = constraint.toString().toLowerCase().trim()

                    for (item in campListFull) {
                        if (item.name.toLowerCase().contains(filterPattern)) {
                            filteredList.add(item)
                        }
                    }
                }

                return FilterResults().apply { values = filteredList }
            }

            @SuppressWarnings("unchecked")
            override fun publishResults(constraint: CharSequence?, results: FilterResults?) {
                campList = results?.values as List<CampClass>
                notifyDataSetChanged()
            }
        }
    }

}
