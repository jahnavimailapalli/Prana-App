package com.example.prana

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.SearchView
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlin.math.pow

class IndividualBloodDonateActivity : AppCompatActivity() {
    private lateinit var userlatitude: String
    private lateinit var userlongitude: String
    private lateinit var mynumber: String
    private lateinit var search: SearchView

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: HospitalAdapter
    private lateinit var adapter2: CampAdapter
    private lateinit var hospitalshift: CardView
    private lateinit var campshift: CardView
    private lateinit var hosptxt: TextView
    private lateinit var camptxt: TextView
    private lateinit var progress: ProgressBar

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_individual_blood_donate)

        mynumber = intent.getStringExtra("mymobile").toString()
        userlatitude = intent.getStringExtra("latitudem").toString()
        userlongitude = intent.getStringExtra("longitudem").toString()

        hospitalshift = findViewById(R.id.hospitalbutton)
        campshift = findViewById(R.id.campbutton)
        hosptxt = findViewById(R.id.hospitaltext)
        camptxt = findViewById(R.id.camptext)
        search = findViewById(R.id.searchviewdonate)
        progress = findViewById(R.id.progressBar_blooddonate)

        hosptxt.setTextColor(resources.getColor(R.color.white))
        camptxt.setTextColor(resources.getColor(R.color.black))
        hospitalshift.setCardBackgroundColor(resources.getColor(R.color.green))
        recyclerView = findViewById(R.id.recycle)
        recyclerView.layoutManager = LinearLayoutManager(this)
        FetchdatafromRealtimeDatabase()

        search.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                if (recyclerView.adapter is HospitalAdapter) {
                    (recyclerView.adapter as HospitalAdapter).filter.filter(newText)
                } else if (recyclerView.adapter is CampAdapter) {
                    (recyclerView.adapter as CampAdapter).filter.filter(newText)
                }
                return true
            }
        })

        campshift.setOnClickListener {
            campshift.setCardBackgroundColor(resources.getColor(R.color.green))
            hospitalshift.setCardBackgroundColor(resources.getColor(R.color.white))
            hosptxt.setTextColor(resources.getColor(R.color.black))
            camptxt.setTextColor(resources.getColor(R.color.white))
            FetchcampdatafromRealtimeDatabase()
        }

        hospitalshift.setOnClickListener {
            campshift.setCardBackgroundColor(resources.getColor(R.color.white))
            hospitalshift.setCardBackgroundColor(resources.getColor(R.color.green))
            hosptxt.setTextColor(resources.getColor(R.color.white))
            camptxt.setTextColor(resources.getColor(R.color.black))
            FetchdatafromRealtimeDatabase()
        }
    }

    private fun FetchcampdatafromRealtimeDatabase() {
        progress.visibility = View.VISIBLE
        val id = "Camps"
        val database = FirebaseDatabase.getInstance()
        val ref = database.getReference(id)

        ref.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val campList = mutableListOf<CampClass>()

                snapshot.children.forEach { dataSnapshot ->
                    val name = dataSnapshot.child("name").value as String? ?: ""
                    val city = dataSnapshot.child("city").value as String? ?: ""
                    val district = dataSnapshot.child("district").value as String? ?: ""
                    val pincode = dataSnapshot.child("pincode").value as String? ?: ""
                    val address = dataSnapshot.child("address").value as String? ?: ""
                    val mobileNum = dataSnapshot.child("mobilenumber").value as String? ?: ""
                    val date = dataSnapshot.child("date").value as String? ?: ""
                    val daysLeft = dataSnapshot.child("daysleft").value as String? ?: ""
                    val daysLeftInt = daysLeft.toIntOrNull() ?: 0
                    val camp = CampClass(address, city, date, daysLeft, daysLeftInt, district, mobileNum, name, pincode)
                    campList.add(camp)
                }

                campList.sortBy { it.dayleftInt }
                adapter2 = CampAdapter(campList)
                recyclerView.adapter = adapter2
                progress.visibility = View.INVISIBLE
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle errors here
            }
        })
    }

    private fun FetchdatafromRealtimeDatabase() {
        progress.visibility = View.VISIBLE
        val id = "Hospitals"
        val database = FirebaseDatabase.getInstance()
        val ref = database.getReference(id)

        ref.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val hospitalList = mutableListOf<HospitalClass>()

                snapshot.children.forEach { dataSnapshot ->
                    val name = dataSnapshot.child("name").value as String? ?: ""
                    val city = dataSnapshot.child("city").value as String? ?: ""
                    val longitude = dataSnapshot.child("longitude").value as String? ?: ""
                    val latitude = dataSnapshot.child("latitude").value as String? ?: ""
                    val pincode = dataSnapshot.child("pincode").value as String? ?: ""
                    val address = dataSnapshot.child("address").value as String? ?: ""
                    val mobileNum = dataSnapshot.child("mobilenumber").value as String? ?: ""
                    val distance = calculateDistance(userlatitude, userlongitude, latitude, longitude)
                    val myDistance = distance.toInt()
                    if (myDistance <= 50) {
                        val hospital = HospitalClass(name, city, distance, pincode, address, mobileNum)
                        hospitalList.add(hospital)
                    }
                }

                hospitalList.sortBy { it.distance }
                adapter = HospitalAdapter(hospitalList)
                recyclerView.adapter = adapter
                progress.visibility = View.INVISIBLE
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle errors here
            }
        })
    }

    fun calculateDistance(lat1: String, lon1: String, lat2: String, lon2: String): Double {
        if (lat1.isEmpty() || lon1.isEmpty() || lat2.isEmpty() || lon2.isEmpty()) {
            return 0.0
        }

        val lat1Rad = Math.toRadians(lat1.toDoubleOrNull() ?: 0.0)
        val lon1Rad = Math.toRadians(lon1.toDoubleOrNull() ?: 0.0)
        val lat2Rad = Math.toRadians(lat2.toDoubleOrNull() ?: 0.0)
        val lon2Rad = Math.toRadians(lon2.toDoubleOrNull() ?: 0.0)

        val deltaLat = lat2Rad - lat1Rad
        val deltaLon = lon2Rad - lon1Rad

        val a = Math.sin(deltaLat / 2).pow(2) + Math.cos(lat1Rad) * Math.cos(lat2Rad) * Math.sin(deltaLon / 2).pow(2)
        val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))

        val earthRadius = 6371.0
        return earthRadius * c
    }
}
